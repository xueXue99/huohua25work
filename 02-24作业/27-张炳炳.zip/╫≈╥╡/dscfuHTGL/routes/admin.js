// 分发路由
const express = require('express');
const router = express.Router();

// 登录页面
router.get('/login', require('./admin-router/login'));
// 登录后的列表
router.get('/productlist', require('./admin-router/productlist.js'));
// 增加商品
router.get('/productadd', require('./admin-router/productadd.js'));
// 修改商品
router.get('/productedit', require('./admin-router/productedit.js'));



// 暴露router
module.exports = router;