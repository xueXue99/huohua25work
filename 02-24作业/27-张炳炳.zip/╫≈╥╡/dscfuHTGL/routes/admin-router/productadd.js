module.exports = (req, res) => {
    res.render('./admin/productadd');
}