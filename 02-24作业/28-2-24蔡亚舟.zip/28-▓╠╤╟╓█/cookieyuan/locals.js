const express=require('express');
const app=express();
const ejs=require('ejs');

// 配置ejs模板
app.set("view engine","ejs");

// 设置一个公共数据
app.locals.user={
    uname:'zbb'
};
app.get('/index',(req,res)=>{
    res.render('index')
})
app.get('/login',(req,res)=>{
    res.render('login')
})
app.listen(3000,()=>{
    console.log('3000端口开启');
})