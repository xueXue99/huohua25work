const express =require('express');
// 引入cookie
const cookieParser=require('cookie-parser');

const app=express();
// use拦截cookie-parser
app.use(cookieParser());
// 设置cookie
app.get('/setCookie',(req,res)=>{
    res.cookie('uname','zhangbb',{
        // 设置过期时间
        maxAge:24*60*60*1000
    })
    res.send('设置成功')
})
// 获取cookie
app.get('/getCookie',(req,res)=>{
    console.log(req.cookies);
    res.send(req.cookies)
})
// 监听端口
app.listen(3000,()=>{
    console.log('3000端口服务开启');
})