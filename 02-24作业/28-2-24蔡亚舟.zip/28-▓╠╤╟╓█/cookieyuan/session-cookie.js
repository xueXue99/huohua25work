const express = require('express');
const { Cookie } = require('express-session');
const session = require('express-session');
// 创建服务
const app = express();
// session简介
// session是一种记录客户端状态的应用,session运行在服务器端，当客户端第一次访问时，可以记录客户的登录信息等
// 当客户端再次访问时,可以判定登录状态,做出提示,进行拦截工作

// session对象key value(Cookie)

app.use(session({
    secret: 'abc',
    name: 'zbb',
    // 强制保存session:默认true不保存,false保存
    resave: false,
    // 强制保存未初始化session
    saveUninitialized: true,
    cookie: {
        // 过期时间
        maxAge: 10 * 1000,
        // secure:true,
    },
    // 强制重置cookie的过期时间
    rolling: true
}));
// 设置登录信息
app.get('/login',(req,res)=>{
    // 设置session的属性
    req.session.isd='lzz';
    res.send('登陆成功')
});
// 判定是否有登录信息存在
app.get('/mainpage',(req,res)=>{
    console.log(req.session.isd);
    if(req.session.isd){
        res.send('欢迎'+req.session.isd+'登录')
    }else{
        res.send('请重新登录');
    }
})
app.listen(3008,()=>{
    console.log('3000开启');
})