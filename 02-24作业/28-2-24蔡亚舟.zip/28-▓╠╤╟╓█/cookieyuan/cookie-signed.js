const express = require('express');
// 引入cookie
const cookieParser = require('cookie-parser');

const app = express();
// use拦截cookie-parser
// 传递一个字符串,作为加密签名的密码
// 设置签名字符串
app.use(cookieParser('123456qwe'))
// 设置cookie
app.get('/setCookie', (req, res) => {
    res.cookie('his', 'tinap', {
        // 设置过期时间
        maxAge: 24 * 60 * 60 * 1000,
        // signed:true (签名)
        signed: true
    })
    res.send('设置成功')
})
// 获取cookie
app.get('/getCookie', (req, res) => {
    console.log(req.cookies);
    console.log(req.signedCookies);
    res.send(req.signedCookies)
})
// 监听端口
app.listen(3000, () => {
    console.log('3000端口服务开启');
})