const express=require('express');
const ejs=require('ejs');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
// 设置模板
app.set("view engine","ejs");
// 跨域
app.use(cors());
app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());
// 静态资源
app.use(express.static('public'));
const admin=require("./routes/admin.js")
app.use('./admin',admin);

app.listen(3000,()=>{
    console.log('3000开启');
})
