let fs = require('fs');
let dataInfo = 'wertyuioplkjhgfcvbnm,kjhgcgnjmkmjghf\n';
// 创建一个写入流
// cWs:<fs.WriteStream>
let cWs = fs.createWriteStream('./files/cw.txt');
// 写入
for (let i = 0; i < 10; i++) {
    cWs.write(dataInfo);
};
// 写入结束
cWs.end();
// 完成
cWs.on('finish', () => {
    console.log('写入文件完成');
});