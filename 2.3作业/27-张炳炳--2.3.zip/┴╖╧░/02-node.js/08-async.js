let fun = () => {
    return new Promise(resolve => {
        setTimeout(function() {
            resolve('执行成功');
        }, 1000);
    });
};
async function funAsync() {
    let rel = await fun();
    console.log(rel);
    console.log('await执行完成');
};

funAsync();