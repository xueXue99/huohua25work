let fs = require('fs');
const { callbackify } = require('util');
// stat(path,callback):判定是文件还是目录
// callbackify(err, stats)
// stats.isDirectory()
// stats.isFile()
// fs.stat('./files/1.txt', (err, stats) => {
//     if (err) {
//         console.log(err);
//     } else {
//         if (stats.isDirectory()) {
//             console.log('是一个目录');
//         } else if (stats.isFile()) {
//             console.log('是一个文件');
//         }
//     };
// });

// // 创建文件夹
// fs.mkdir('./files/css', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('目录创建成功');
//     }
// });

// // 删除文件夹
// fs.rmdir('./files/css', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('目录删除成功');
//     }
// });

// 删除一个非空文件夹
// fs.rmdir('./files/test', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('目录删除成功');
//     }
// });

// 读取文件夹
fs.readdir('./files/test', (err, files) => {
    if (err) {
        console.log(err);
    } else {
        // files是一个数组--所有文件的文件名['001.txt','002.txt'];
        console.log(files);
        console.log(files[1]);
    }
});