//导入
import { firstName } from './module1.js';

// export default 向外暴露的成员 ,可以使用任意变量接受

import zz from './module1.js';
console.log(firstName);
console.log(zz());