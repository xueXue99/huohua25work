var firstName = 'cyz';
var secondName = '18';
var gender = true;

function getAge() {
    return getAge;
}

function setAge() {
    age++;
}

function funn() {
    console.log('默认导出');
    return 'morning';
}
// 导出
export { firstName, secondName };
// 通过 as 改变变量名
export { getAge as getterAge };
// export 可以有多个
// - export default 不需要加{};只能有一个
export default funn;