let fs = require('fs');

function delDir(url) {
    let list = fs.readdirSync(url);
    list.forEach((value, index) => {
        // 拼接路径
        let newUrl = url + '/' + value;
        // 读取文件信息
        let stats = fs.statSync(newUrl);
        // 判断是文件还是文件夹
        if (stats.isFile()) {
            // 当前为文件,则删除文件
            fs.unlinkSync(newUrl);
        } else {
            // 当前为文件夹,则递归调用自身
            arguments.callee(newUrl)
        }
    });
    fs.rmdirSync(url);
}
delDir('./files/test');