// promise:就是容器--包裹异步执行程序
let pro = new Promise(function(resolve, reject) {
    setTimeout(function() {
        let num = Math.floor(Math.random() * 10);
        console.log(num);
        if (num < 3) {
            resolve('执行成功')
        } else {
            reject('执行失败')
        }
    }, 1000);
});
pro.then(function(data) {
    console.log(data);
}, function(err) {
    console.log(err);
});