// generator函数用*标识,用yield挂起函数的执行程序,通过next()方法执行
function* fun() {
    console.log(1);
    yield '11';
    console.log(2);
    yield '22';
    console.log(3);
    yield 'end';
}

let rel = fun();
console.log(rel.next().value);
console.log(rel.next());
console.log(rel.next());
console.log(rel.next());