let fs = require('fs');

// 写入文件 fs.writeFile()
// --如果文件不存在,则会自动创建
// 如果文件内存在内容,则会覆盖
// fs.writeFile('./files/2.txt', '00把电位器让我悄悄过去各个', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('写入成功');
//     }
// });

// //追加数据
// fs.appendFile('./files/2.txt', '\n追加数据', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('追加成功');
//     }
// });

// 删除文件

// fs.unlink('./files/del.txt', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// });

// 重命名文件夹

fs.rename('./files/rename.txt', './files/name.text', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('重命名成功');
    }
});