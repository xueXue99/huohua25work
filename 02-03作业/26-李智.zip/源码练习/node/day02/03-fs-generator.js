let fs = require('fs');
// 读取文件
let read = function(filename) {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, 'utf-8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    });
};
// 重命名文件
let rename = function(oldFile, newFile) {
    return new Promise((resolve, reject) => {
        fs.rename(oldFile, newFile, (err) => {
            if (err) {
                reject(err);
            } else {
                resolve('重命名成功');
            }
        });
    });
};
function* gener() {
    yield read('./files/1.txt');
    yield read('./files/22.txt');
    yield rename('./files/rename.txt','./files/name.txt');
}
// 使用变量保存
let rel = gener();
// console.log(rel.next().value);
// 由于返回值是一个promise对象，所以

rel.next().value.then((data) => {
    console.log(data);
    return rel.next().value;
}).then((data) => {
    console.log(data);
    return rel.next().value;
}).then((data) => {
    console.log(data);
})