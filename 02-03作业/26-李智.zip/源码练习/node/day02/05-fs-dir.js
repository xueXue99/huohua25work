let fs = require('fs');
// 判断文件类型
// fs.stat('./files/1.txt', (err, stats) => {
//     if (err) {
//         console.log(err);
//     } else {
//         if (stats.isDirectory()) {
//             console.log('这是一个目录');
//         } else if (stats.isFile()) {
//             console.log('这是一个文件');
//         }
//     }
// })
// 创建新文件
// fs.mkdir('./files/css',(err) => {
//     console.log('创建成功');
// })
// 删除文件夹(非空文件夹)
// fs.rmdir('./files/css',(err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// })
// 读取文件夹([ '1.txt', '22.txt', 'rename.txt' ],只能读取一层)
// fs.readdir('./files',(err,file) => {
//     if(err){
//         console.log(err);
//     }else{
//         console.log(file);
//     }
// })
// 递归创建文件夹(依次创建)
// fs.mkdir('./files/css/css.css', {
//     recursive: true
// }, (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('创建成功');
//     }
// })
// 读取文件夹文件的类型
// fs.readdir('./files',{
//     withFileTypes: true
// },(err,file) => {
//     if(err){
//         console.log(err);
//     }else{
//         console.log(file);
//     }
// })
// 非空
fs.readdir('./css', (err, file) => {
    if (err) {
        console.log(err);
    } else {
        
        fs.stat(file, (err, stats) => {
            if (err) {
                console.log(err);
            } else {
                if (stats.isDirectory()) {
                    console.log('这是一个目录');
                } else if (stats.isFile()) {
                    console.log('这是一个文件');
                }
            }
        })
        if (file.isDirectory()) {

        } else if (file.isFile()) {

        }
    }
})
// fs.rmdir('./css',(err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// })