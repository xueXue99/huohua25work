let fs = require('fs');
let data = 'Today is nice day\n';
// 创建写入流
let cWS = fs.createWriteStream('./files/cw.txt');
// 写入
// cWS.write(data);
// 多次写
for(let i = 0;i<100;i++){
    cWS.write(data);
}
// 结束
cWS.end()
// 完成
cWS.on('finish',()=>{
    console.log('写入完成');
})