let fs = require('fs');
// 最多64kb
let cRW = fs.createReadStream('./files/cw.txt');
// 存储读取的数据
let str ='';
// data:用于读取数据
cRW.on('data',(datastr) => {
    str += datastr;
});
// 读取数据并打印
cRW.on('end',() => {
    console.log(str);
})