let fs = require('fs');
// 创建读取流
let cRS = fs.createReadStream('./files/1.txt');
// 创建写入流
let cWS = fs.createWriteStream('./files/22.txt');
// 读取流的方法
将1的数据写入2
cRS.pipe(cWS)
// 完成
cRS.on('end',(err) => {
    
})