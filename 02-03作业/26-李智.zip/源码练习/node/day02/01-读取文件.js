let fs = require('fs');
// 读取文件
// fs.readFile('./files/1.txt','utf-8',(err,data) =>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log(data);
//     }
// })
// 写入文件
// fs.writeFile('./files/2.txt','aaabbbcccdddd',(err) =>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log('写入成功');
//     }
// })
// 追加文件
// fs.appendFile('./files/2.txt','1212',(err) => {
//     if(err){
//         console.log(err);
//     }else{
//         console.log('添加成功');
//     }
// })
// 删除文件
// fs.unlink('./files/2.txt', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// })
// 重命名文件
fs.rename('./files/2.txt', './files/22.txt', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('改名成功');
    }
})
// 捕获异常
try {
    let data = fs.readFileSync('./files/3.txt', 'utf8');
    console.log(data);
} catch (error) {
    console.log(error);
}