let fs = require('fs');
const { resolve } = require('path');
// 读取
let read = function(name){
    return new Promise((resolve,reject) => {
        fs.readFile(name,'utf-8',(err,data) => {
            if(err){
                reject(err);
            }else{
                resolve(data)
            }
        })
    })
}
// 重命名
let rename = function(oldname,newname){
    return new Promise((resolve,reject) => {
        fs.rename(oldname,newname,(err) => {
            if(err){
                reject(err)
            }else{
                resolve('命名成功')
            }
        })
    })
}
// 顺序：先读取1，在读取2，再修改名
read('./files/1.txt').then((data) => {
    console.log(data);
    return read('./files/22.txt');
}).then((data) => {
    console.log(data);
    return rename('./files/name.txt','./files/rename.txt')
}).then((data) => {
    console.log(data);
})