// fs.file system
// 读取文件
//写入文件
//追加内容
// 删除文件
// 重命名文件.i...
// require:引入模块
let fs = require('fs');
// console.log(fs);
// 读取文件
// fs.readFile()
// ./同级
// ../上级
// fs.readFile('./files/1.txt',(err,data)=>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log(data.toString());
//     }
// })
// fs.readFile('./files/2.txt','utf8',(err,data)=>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log(data);
//     }
// })
// 写入文件
// fs.writeFile('./files/2.txt','你好，小艾同学',(err)=>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log('追加成功');
//     }
// })
// 追加数据
// fs.appendFile('./files/2.txt','这是我追加的内容',(err)=>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log('追加成功');
//     }m
// })
// 删除文件
// fs.unlink('./files/1.txt',(err)=>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log('删除成功');
//     }
// })
// 重命名文件
fs.rename('./files/2.txt','./files/02.txt',(err)=>{
    if(err){
        console.log(err);
    }else{
        console.log('重命名成功');
    }
})