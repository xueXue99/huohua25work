let fs = require('fs')
// let data = fs.readFileSync('./files/02.txt', 'utf8');
//     console.log(data);
try {
    let data = fs.readFileSync('./files/02.txt', 'utf8');
    console.log(data);
} catch (error) {
    // console.log(error);
}