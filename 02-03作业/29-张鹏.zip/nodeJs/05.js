let fs = require('fs');
// 读取文件
let read = function(filename) {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, 'utf-8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    });
};
// 重命名文件
let rename = function(oldFile, newFile) {
    return new Promise((resolve, reject) => {
        fs.rename(oldFile, newFile, (err) => {
            if (err) {
                reject(err);
            } else {
                resolve('重命名成功');
            }
        });
    });
};
// 申明generator函数
function* readfi() {
    yield read('./files/02.txt');
    yield read('./files/03.txt');
    yield rename('./files/rename.txt', './files/name.txt');
};
var relf = readfi();
relf.next().value.then(data => {
    console.log(data);
    return relf.next().value;
}).then(data => {
    console.log(data);
    return relf.next().value;
}).then(data => {
    console.log(data);
});