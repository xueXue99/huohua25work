// 一个js文件就是一个模块
var module1=require('./01-module1.js');
console.log(module1.name);
console.log(module1.age);
console.log(module1.getAge());