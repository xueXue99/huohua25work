let name = 'zbb';
let age = 25;

function getAge() {
    return age;
}
// 暴露属性
// console.log(module.exports);
// module.exports.name = name;
// module.exports.age = age;
// module.exports.getAge = getAge;
// 空对象
// module.exports = {};
// module.exports和exports共同指向同一个对象
// 导出内容
exports = module.exports = {
    name: name,
    age: age,
    getAge: getAge
}