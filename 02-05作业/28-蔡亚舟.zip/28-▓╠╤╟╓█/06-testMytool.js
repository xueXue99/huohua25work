let mytool = require('mytool/mytool');

console.log(mytool);
console.log(mytool.add(1, 2));