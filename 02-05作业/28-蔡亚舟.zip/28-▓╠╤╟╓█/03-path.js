const fs=require('fs');
// __dirname 文件目录
console.log(__dirname);
// 读取文件最好采用绝对路径,更保险
fs.readFile(__dirname+'/files/test.txt',(err,data)=>{
    if(err){
        console.log(err);
    }else{
        console.log(data.toString());
    }
})
console.log('测试完成');