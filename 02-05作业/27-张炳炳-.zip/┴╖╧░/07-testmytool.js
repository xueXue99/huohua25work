//  创建myProject 目录
// mkdir  myProject
//  切换到myProject目录下
// cd   myProject
//  创建 package.json文件
// npm  init
let package = {
    // 项目名
    "name": "myproject",
    // 版本号
    "version": "1.0.0",
    // 项目描述
    "description": "",
    // 项目入口文件
    "main": "index.js",
    // 启动项目的测试代码
    "scripts": {
        "test": "echo \"Error: no test specified\" && exit 1"
    },
    // 关键词
    "keywords": [
        "init"
    ],
    // 作者
    "author": "",
    // 项目发行时需要的证书
    "license": "ISC"
};


// npm help XXX:查看帮助文档