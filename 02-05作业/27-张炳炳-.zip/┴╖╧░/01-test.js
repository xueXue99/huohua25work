// 安装nrm: 
//  npm install nrm -g  //全局安装  --nrm -V 查看当前版本

// nrm ls 查看所有备用仓储  ---带*的为当前使用仓储

// nrm use [仓储名]   切换仓储

// npm install  XX    下载包

// 测试相应仓储速度
// nrm test npm
// nrm test taobao