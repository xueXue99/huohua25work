// 引入内置模块
const fs = require('fs');

// 读取文件
// console.log(__dirname);--当前模块的目录名
// console.log(__filename);--当前文件的文件名

// 使用绝对路径读取文件
fs.readFile(__dirname + '/files/1.txt', 'utf-8', (err, data) => {
    if (err) {
        console.log(err);
    } else {
        console.log(data);
    }
});