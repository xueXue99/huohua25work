// 一个js文件就是一个模块
const modele1 = require('./03-module1');
console.log(modele1.firstName);
console.log(modele1.age);
console.log(modele1.getAge);

// 03-module1  中不暴露出的属性无法访问