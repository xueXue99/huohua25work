const lodash = require('lodash');
console.log(lodash);

// 第三方模块可以从node_module文件夹中进行加载