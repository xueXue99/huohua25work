for (let i = 0; i < 3; i++) {
    console.log(i);
};

// 下载
// nom install -g nodemon
// nom install -g supervisor
// 安装在全局

// 使用方式:
// 在命令窗口,使用nodemon代替node启动文件:
// nodemon xxx.js 代替 node xxx.js