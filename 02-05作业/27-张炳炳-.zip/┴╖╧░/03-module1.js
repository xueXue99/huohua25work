let firstName = 'cyz';
let age = 20;

function getAge() {
    return age;
}

//暴露属性

// console.log(module.exports);
// module.exports.firstName = firstName;
// module.exports.age = age;
// module.exports.getAge = getAge;

// module.exports = {};
// module.exports和exports共同指向同一个对象

// exports.firstName = firstName;
// exports.age = age;

// 如果重新为exports和module.exports重新赋值以module.exports优先
// exports = {
//     age: age
// };
// module.exports = {
//     firstName: firstName
// };

// 导出多个内容
exports = module.exports = {
    firstName: firstName,
    age: age,
    getAge: getAge
};

// 总结: 
// 1. exports对象是module对象的一个属性， 在初始时exports和module.exports是指向同一块内存区域的；
// 2. 在不改变exports内存指向的情况下， 修改exports的值可以改变module.exports的值；
// 3. 导出尽量使用module.exports以避免混淆。