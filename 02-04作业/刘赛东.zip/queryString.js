const queryStr = require('querystring');
let searchstr = 'uname=zhangmeili&password=666'
console.log(queryStr.parse(searchstr)); //将字符串转换为对象:[Object: null prototype] { uname: 'zhangmeili', password: '666' }
console.log(queryStr.stringify({ uname: 'zhangmeili', password: '666' }, '*', '-')); // uname - zhangmeili * password - 666 连接， 不写返回窗体格式
console.log(queryStr.escape('刘赛东')); //编码  %E5%88%98%E8%B5%9B%E4%B8%9C
console.log(queryStr.unescape('%E5%88%98%E8%B5%9B%E4%B8%9C')); //解码 刘赛东