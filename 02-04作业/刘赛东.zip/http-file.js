var http = require('http');
var server = http.createServer((req, res) => {
    res.writeHead(200, 'okk', {
        'Content-Type': 'text/html;charset=utf-8'
    });
    console.log(req.url);
    switch (req.url) {
        case '/':
            res.write('index.html');
            break;
        case '/index.html':
            res.write('index.html');
            break;
        case '/news.html':
            res.write('news.html');
            break;
        default:
            res.write('404')
    }
    res.end('okk')
});
server.listen(3000, () => {
    console.log('123');
})