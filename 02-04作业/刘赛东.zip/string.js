const http = require('http');
const queryStr = require('querystring');
let server = http.createServer((req, res) => {
    res.writeHead(200, {
        'Content-type': 'text/html;charset=utf-8'
    });
    let reqURL = req.url;
    let obj = {};
    if (reqURL.includes('?')) {
        var reqstr = reqURL.split('?')[1];
        console.log(reqstr);
        console.log(queryStr.parse(reqstr));
        res.end('200');
    } else {
        res.end('404');
    }
});
server.listen(3000, () => {
    console.log('ok');
});