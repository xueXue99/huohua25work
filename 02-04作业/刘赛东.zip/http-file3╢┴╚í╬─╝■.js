var http = require('http');
var fs = require('fs');
var server = http.createServer((req, res) => {
    res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
    });
    console.log(req.url);
    var url = './files' + req.url;
    fs.readFile(url, (err, data) => {
        if (err) {
            console.log(err);
        } else {
            res.write(data)
        }
        res.end('成功')
    })
});
server.listen(3000, () => {
    console.log('200');
})