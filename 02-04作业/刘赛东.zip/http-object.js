var http = require('http');
var server = http.createServer((req, res) => {
    res.writeHead(200, {
        'Content-type': 'text/html;charset=utf-8'
    });
    let reqURL = req.url;
    var obj = {};
    if (reqURL.includes('?')) {
        var arr = reqURL.split("?")[1].split('&');
        arr.forEach((value) => {
            var temp = value.split('=');
            obj[temp[0]] = temp[1]
        });
        console.log(obj);
        res.end('ok');

    } else {
        res.end('404')
    }
});
server.listen(3000, () => {
    console.log('200');
})