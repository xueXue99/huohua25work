const queryStr = require('querystring');
let searchstr = 'uname=zhangmeili&password=666'
console.log(queryStr.parse(searchstr));
console.log(queryStr.stringify({ uname: 'zhangmeili', password: '666' }, '*', '-')); // uname - zhangmeili * password - 666 连接， 不写返回窗体格式
var str = 'kdjghfakfkhafshkk'
console.log(queryStr.parse(str)); //[Object: null prototype] { kdjghfakfkhafshkk: '' }