var path = require('path');
console.log(path.basename('http://www.hg-zn.com:3000/index.html')); //index.html
console.log(path.basename('http://www.hg-zn.com:3000/index.html', '.html')); //index
console.log(path.dirname('http://www.hg-zn.com:3000/abc/index.html')); // http://www.hg-zn.com:3000/abc
console.log(path.parse('http://www.hg-zn.com:3000/abc/index.html'));
// {
//     root: '',
//     dir: 'http://www.hg-zn.com:3000/abc',
//     base: 'index.html',
//     ext: '.html',
//     name: 'index'
//   }
console.log(path.join('abc', 'def', 'ght')); //连接后的abc\def\ght


console.log(path.basename('http://www.hg-zn.com:3000/index.html'));
console.log(path.basename('http://www.hg-zn.com:3000/index.html', '.html'));
console.log(path.basename('http://www.hg-zn.com:3000/login?uname=zhangmeili', '.html')); //login?uname=zhangmeili
console.log(path.dirname('http://www.hg-zn.com:3000/abc/index.html'));
console.log(path.parse('http://www.hg-zn.com:3000/abc/index.html'));
console.log(path.join('abc', 'def', 'ght'));


console.log(path.basename('http://www.hg-zn.com:3000/index.html'));
console.log(path.basename('http://www.hg-zn.com:3000/login?uname=zhangmeili', '.html')); //login?uname=zhangmeili
console.log(path.dirname('http://www.hg-zn.com:3000/abc/index.html'));
console.log(path.parse('http://www.hg-zn.com:3000/abc/index.html'));
console.log(path.join('abc', 'def', 'ght'));