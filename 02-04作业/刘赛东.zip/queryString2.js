const queryStr = require('querystring');
let searchstr = 'uname=zhangmeili&password=666'
console.log(queryStr.stringify({ uname: 'zhangmeili', password: '666' }, '-', '=')); // uname=zhangmeili - password = 666 连接， 不写返回窗体格式
console.log(queryStr.escape('好谷')); //编码  %E5%A5%BD%E8%B0%B7
console.log(queryStr.unescape('%E5%A5%BD%E8%B0%B7')); //解码 好谷