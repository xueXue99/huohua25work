let url = new URL('http://www.hg-zn.com:3000/login?uname=zhangmeili&password=666#888888');
console.log(url.hash); //返回#以后的
console.log(url.host); //返回主机名端口号
console.log(url.hostname); //返回主机名
console.log(url.href); //返回完整地URL
console.log(url.origin); //域返回/前面的
console.log(url.protocol); //http
console.log(url.search); //返回？号以后的
console.log(url.searchParams); // URLSearchParams{ 'uname' => 'zhangmeili', 'password' => '666' }
console.log(url.toString()); //http://www.hg-zn.com:3000/login?uname=zhangmeili&password=666#888888
console.log(url.toJSON()); //http://www.hg-zn.com:3000/login?uname=zhangmeili&password=666#888888
// 声明请求url参数
var arr = url.searchParams;
for (let [key, value] of arr) {
    console.log(key);
    console.log(value);
}
//uname
// zhangmeili
// password
// 666
// 添加
arr.append('age', 18);
// 删除
arr.delete('age');
console.log(arr);
console.log(arr.entries()); //URLSearchParams Iterator { [ 'uname', 'zhangmeili' ], [ 'password', '666' ] }
console.log(arr.get('uname'));
console.log(arr.getAll('uname')); //返回数组
console.log(arr.has('uname')); //有没有这个参数
console.log(arr.keys()); //返回key