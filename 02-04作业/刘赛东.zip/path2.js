var path = require('path');
console.log(path.basename('http://www.hg-zn.com:3000/index.html'));
console.log(path.basename('http://www.hg-zn.com:3000/index.html', '.html'));
console.log(path.dirname('http://www.hg-zn.com:3000/abc//bdc/index.html'));
console.log(path.parse('http://www.hg-zn.com:3000/abc/bcd/index.html'));
console.log(path.join('123', '456', '789'));