const http = require('http');
const fs = require('fs');

// 创建服务器
let server = http.createServer((req, res) => {
    res.writeHead(200, 'success', {
        'Content-type': 'text/html;chartset=utf-8'
    });
    if (req.url != '/favicon.ico') {
        let filePath = './files' + req.url;
        fs.readFile(filePath, (err, data) => {
            if (err) {
                console.log(err);
            } else {
                res.write(data);
            };
            // 读完响应就结束
            res.end();
        })
    }
});
// 监听端口号
server.listen(3000, () => {
    console.log('server is running:3000');
});