const http = require('http');

// 创建服务器
let server = http.createServer((req, res) => {
    // console.log(req);
    // 获取客户端请求url的信息
    // http://localhost:3000/about.html

    console.log(req.url);

    // 设置相应消息message
    res.writeHead(200, 'success', {
        'Content-Type': 'text/html;charset=utf-8'
    });
    switch (req.url) {
        case '/':
            res.write('home page');
            break;
        case '/index.html':
            res.write('home page');
            break;
        case '/about.html':
            res.write('about page');
            break;
        default:
            res.write('404 Not Fond');
    };
    // 响应结束
    res.end();
});

// 监听端口号
server.listen(3000, () => {
    console.log('server is running:3000');
});