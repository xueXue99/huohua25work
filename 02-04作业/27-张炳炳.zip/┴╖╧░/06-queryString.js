// 引入查询字符串的模块
const queryStr = require('querystring');

// querystring.decode() === querystring.parse(str[, sep[, eq[, options]]])
// querystring.encode() === querystring.stringify(obj[, sep[, eq[, options]]])
// querystring.escape(str)
// querystring.unescape(str)

let searchstr = 'uname=cyz&password=123';
// 将字符串转化为对象--返回的对象不是原型地继承自 JavaScript 的 Object。
//  这意味着典型的 Object 方法如 obj.toString()、 obj.hasOwnProperty() 等都没有被定义并且不起作用。
//[Object: null prototype] { uname: 'zhangmeili', password: '666' }
console.log(queryStr.parse(searchstr));
// uname=zhangmeili&password=666
console.log(queryStr.stringify({ uname: 'zhangmeili', password: '666' }));

// 编码和解码
console.log(queryStr.escape('uname=蔡亚舟&password=666'));
console.log(queryStr.unescape('uname%3D%E8%94%A1%E4%BA%9A%E8%88%9F%26password%3D666'));