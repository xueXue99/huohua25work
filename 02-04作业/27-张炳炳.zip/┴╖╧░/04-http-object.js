const http = require('http');
let server = http.createServer((req, res) => {
    // 设置响应头
    res.writeHead(200, {
        'Content-type': 'text/html;charset=utf-8'
    });
    // 获取请求的url相关内容
    // http://localhost:3000/login?uname=cyz&password=123
    // /login?uname=cyz&password=123
    console.log(req.url);
    // 转存为对象
    // {
    //     uname: 'cyz',
    //     password: 666
    // }
    let reqUrl = req.url;
    if (reqUrl != './favicon.ico') {
        // 申明转存的obj对象
        let obj = {};
        if (reqUrl.includes('?')) {
            let arr = reqUrl.split('?')[1].split('&');
            // 存到对象中
            arr.forEach((value) => {
                let tempArr = value.split('=');
                obj[tempArr[0]] = tempArr[1];
            });
            console.log(obj);
            // 结束
            res.end();
        } else {
            res.end('无参数存储');
        }
    };
});
// 监听端口号
server.listen(3000, () => {
    console.log('server is running:3000');
});