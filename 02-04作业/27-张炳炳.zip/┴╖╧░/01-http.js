let http = require('http');
// console.log(http);
// 使用createServer()创建服务器
// request:请求
// response:返回消息等内容
let server = http.createServer((req, res) => {
    // 设置响应信息-相应类型及编码方式
    res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
    });
    // 写入前台
    res.write('欢迎访问');
    // 响应结束
    res.end();
});
// 监听
server.listen(3000, () => {
    console.log('Sercer is running,Press Ctrl + c will stop');
});