let url = new URL('http://www.hg-zn.com:3000/login?uname=zhangmeili&password=666#888888');
// console.log(url);
//获取锚位置（#位置后面）
// console.log(url.hash);//#888888
// 获取主机名与端口号
// console.log(url.host);//www.hg-zn.com:3000
// 获取主机名
// console.log(url.hostname);//www.hg-zn.com
// 完整的url
// console.log(url.href);//http://www.hg-zn.com:3000/login?uname=zhangmeili&password=666#888888
// 获取域名
// console.log(url.origin);//http://www.hg-zn.com:3000
// 获取路径（文件前的路径）
// console.log(url.pathname);// /login
// 获取端口号
// console.log(url.port);//3000
// 获取协议
// console.log(url.protocol);//http:
// 获取？后面的内容(不包含锚)
// console.log(url.search);//?uname=zhangmeili&password=666
// 以对象形式输出传递的参数
// console.log(url.searchParams);//URLSearchParams { 'uname' => 'zhangmeili', 'password' => '666' }
let URLSearch = url.searchParams;
// 解构
for(let [key,value] of URLSearch){
    // console.log(key);//uname，passWord
    // console.log(value);//zhamgmeili,666
}
//forEach
URLSearch.forEach((value,index) => {
    // console.log(index);//uname，passWord
    // console.log(value);//zhamgmeili,666
})
// 一些方法
// 添加参数
// URLSearch.append('gender', '女');
// 删除参数
// URLSearch.delete('gender');
// 查看键值对
// console.log(URLSearch.entries());
// 查找
// console.log(URLSearch.get('uname'));//zhamgmeili
// 查找所以并返回一个数组
// console.log(URLSearch.getAll('uname'));//['zhangmeili]
// 判断是否含有，返回值是布尔值
// console.log(URLSearch.has('uname'));//true
// 返回key
// console.log(URLSearch.keys());
// 添加key，依次添加，不会覆盖
URLSearch.append('key', '111');
URLSearch.append('key', '222');
URLSearch.append('key', '333');
console.log(URLSearch);
// 只获取一次，而且只获取第一个
console.log(URLSearch.get('key'));
// 获取全部，返回一个数组
console.log(URLSearch.getAll('key'));