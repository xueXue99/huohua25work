// 引入查询字符串的模块
let queryStr = require('querystring');

let searchstr = 'uname=zhangmeili&password=666'
// 将字符串转换为对象
// console.log(queryStr.parse(searchstr));//[Object: null prototype] { uname: 'zhangmeili', password: '666' }
// 将对象转换为窗体格式
// console.log(queryStr.stringify({ uname: 'zhangmeili', password: '666' }));
// 改变格式uname-zhangmeili*password-666
// console.log(queryStr.stringify({ uname: 'zhangmeili', password: '666' }, '*', '-'));

// 编码和解码
// console.log(queryStr.escape('node学习666'));//node%E5%AD%A6%E4%B9%A0666
// console.log(queryStr.unescape('node%E5%AD%A6%E4%B9%A0666'));//node学习666
let codeStr = 'uname=%E5%BC%A0%E7%BE%8E%E4%B8%BD&pwd=666';
//将编码转换为对象
console.log(queryStr.parse(codeStr));