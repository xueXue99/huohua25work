let http = require('http');
// 创建服务器
// url='http://localhost:3000/login?uname=zhangmeili&password=666'
let serve = http.createServer((req, res) => {
    // 设置响应头
    res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
    });
    // 获取URL内容
    let reqUrl = req.url;
    // 筛选文件
    if (reqUrl != './favicon.ico') {
        // 创建一个对象来保存
        let obj = {};
        // 如果含有？
        if (reqUrl.includes('?')) {
            // 先切割
            let str = reqUrl.split('?')[1].split('&');
            console.log(str);//[ 'uname=zhangmeili', 'password=666' ]
            // 遍历并保存
            str.forEach((value,index) => {
                let temp = value.split('=');
                obj[temp[0]] = temp[1];
            })
            console.log(obj);//{uname:'zhangmeili',passward:'666'}
            res.end('成功');
        }
    } else {
        res.end('结束');
    }
})
// 开启端口的监听
serve.listen(3000, () => {
    console.log('服务器开启');
});