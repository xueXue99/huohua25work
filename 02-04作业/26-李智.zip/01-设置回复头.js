let http = require('http');
// 设置响应信息
let serve = http.createServer((req,res) => {
    res.writeHead(200,{
        'Content-Type':'text/html;charset=utf-8'
    });
    // 写入文件
    res.write('您好')
    res.write('<p>您好</p>')
    // 结束
    res.end()
})
// 监听事件
serve.listen(3000,() =>{
    console.log('服务器已打开');
})