let path = require('path');
// basename:path最后文件名
// console.log(path.basename('http://localhost:3000/index.html'));//index.html
// console.log(path.basename('http://localhost:3000/index.html', '.html'));//index
// 没有的话依然是最后文件名
// console.log(path.basename('http://localhost:3000/login?uname=zhangmeili'));//login?uname=zhangmeili

// path 的目录名（没有‘/’）
// console.log(path.dirname('http://localhost:3000/index.html'));// http://localhost:3000
// console.log(path.dirname('http://localhost:3000/public/module/css/index.html'));// http://localhost:3000/public/module/css
// url的扩展名
// console.log(path.extname('http://localhost:3000/public/module/css/index.html'));//.html
// 转换为对象
// {
//     root: '',
//     dir: 'http://localhost:3000',
// basename
//     base: 'login?uname=zhangmeili&password=666',
// extname
//     ext: '',
// 文件名
//     name: 'login?uname=zhangmeili&password=666'
//   }
// console.log(path.parse('http://localhost:3000/index.html'));
// console.log(path.parse('http://localhost:3000/login?uname=zhangmeili&password=666'));
// 拼接目录
console.log(path.join('public', 'module', 'css'));// public\module\css