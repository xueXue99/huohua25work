let http = require('http');
// 设置响应信息
let serve = http.createServer((req, res) => {
    res.writeHead(200, 'success', {
        'Content-Type': 'text/html;charset=utf-8'
    });
    // 打开不同文件会修改写入内容
    switch (req.url) {
        // 代表主页
        case '/':
            res.write('主页')
            break;
        case '/index.html':
            res.write('首页')
            break;
        case '/page1.html':
            res.write('页面1')
            break;
        case '/page2.html':
            res.write('页面2')
            break;
        default:
            res.write('没有找到')
            break;
    }
    // 结束
    res.end('结束')
})
// 监听事件
serve.listen(3000, () => {
    console.log('服务器已打开');
})