let http = require('http');
// 创建服务器
let server = http.createServer((req, res) => {
    // console.log(req);
    console.log(req.url);
    // 设置相应消息message
    res.writeHead(200, 'success', {
        'Content-Type': 'text/html;charset=utf-8'
    });
    switch (req.url) {
        case '/':
            res.write('home page');
            break;
        case '/index.html':
            res.write('home page');
            break;
        case '/news.html':
            res.write('news page');
            break;
        case '/about.html':
            res.write('aboutus page');
            break;
        default:
            res.write('404 Not Fond');
    }
    // 响应结束
    res.end('完成');
});
server.listen(3000, () => {
    console.log('server is running:3000');
});