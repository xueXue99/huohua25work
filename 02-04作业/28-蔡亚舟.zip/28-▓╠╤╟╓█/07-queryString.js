const http = require('http');
const server = http.createServer((req, res) => {
    res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
    })
    console.log(req.url);
    // 将url变成对象
    let reqUrl = req.url;
    if (reqUrl != '/favicon.ico') {
        let obj = {};
        if (reqUrl.includes('?')) {
            var arr = reqUrl.split('?')[1].split('&')
            arr.forEach((value) => {
                var newArr = value.split('=')
                obj[newArr[0]] = newArr[1]
            })
            res.end('成功')
        } else {
            res.end('无数据')
        }
    }
});
server.listen(3000, () => {
    console.log('server is running:3000');
});