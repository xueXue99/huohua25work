// 引入查询字符串的模块
const queryStr = require('querystring');

// querystring.decode() 
// querystring.parse(str[, sep[, eq[, options]]])
// querystring.encode()
// querystring.stringify(obj[, sep[, eq[, options]]])
// querystring.escape(str)
// querystring.unescape(str)

let searchstr = 'uname=zbb&password=111';
// 将字符串转换为对象
console.log(queryStr.parse(searchstr));
console.log(queryStr.stringify({
    uname: 'zbb',
    password: '111'
}));

// 编码和解码
let codeStr = 'uname%3D%E5%BC%A0%E7%82%B3%E7%82%B3%26password%3D666';
console.log(queryStr.parse(codeStr));
console.log(queryStr.unescape('%3D%E5%BC%A0%E7%82%B3%E7%82%B3%26'));