let http = require('http');
let fs = require('fs');
// 创建服务器
let server = http.createServer((req, res) => {
    console.log(req);
    // 设置格式
    res.writeHead(200, 'success', {
        'Content-Type': 'text/html;charset=utf-8'
    });
    if (req.url != '/favicon.ico') {
        let filePath = './files' + req.url;
        console.log(filePath);
        fs.readFile(filePath, (err, data) => {
            if (err) {
                console.log(err);
            } else {
                res.write(data);
            }
            //响应结束
            res.end('end');
        });
    }
});
server.listen(3000, () => {
    console.log('server is running:3000');
});