let url=new URL('http://www.hg-zn.com:3000/login?uname=zbb&password=zzzcc#hh');
// console.log(url);
// // 锚位置#
// console.log(url.hash);
// // 主机名和端口号
// console.log(url.host);
// // 主机名
// console.log(url.hostname);
// // 完整的url
// console.log(url.href);
// // 域
// console.log(url.origin);
// // 端口号
// console.log(url.port);
// // 协议
// console.log(url.protocol);
// 请求url
let searchpar=url.searchParams;
console.log(searchpar);
for (let [key, value] of searchpar) {
    console.log(key);
    console.log(value);
};
// 遍历
searchpar.forEach((value,key)=>{
    console.log(key);
    console.log(value);
})
searchpar.append('gender', '男');
searchpar.delete('password');
console.log(searchpar);
console.log(searchpar.entries());
console.log(searchpar.get('gender'));
console.log(searchpar.getAll('gender'));
console.log(searchpar.has('uname'));
console.log(searchpar.keys());
searchpar.append('key', 'aaa');
searchpar.append('key', 'bbb');
searchpar.append('key', 'ccc');
console.log(searchpar);
console.log(searchpar.get('key'));
console.log(searchpar.getAll('key'));