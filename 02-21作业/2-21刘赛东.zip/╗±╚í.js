let mongoose = require('mongoose');
let experss = require('express');
let ejs = require('ejs');
let fs = require('fs');
let app = experss();
app.set('view engine', 'ejs');
let DB = mongoose.connect('mongodb://localhost/mongodemo', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('成功');
}, () => {
    console.log('失败');
});
// 定义规则
let userSchema = new mongoose.Schema({
    name: String,
    age: Number,
    gender: String
});
let User = mongoose.model('user', userSchema);
// User.find().then((data) => {
//     console.log(data);
// });
app.get('/', (req, res) => {
    User.find().then((data) => {
        res.render('index', { data: data })
    });
})
app.listen(3000, () => {
    console.log(3000);
})