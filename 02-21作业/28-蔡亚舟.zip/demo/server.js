// 引入模块
const express = require('express');
const fs = require('fs');
const ejs = require('ejs');
const mongoose = require('mongoose');
const app = express();
const bodyParser = require('body-parser');

app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({
    extended: false
}));
var DB = mongoose.connect('mongodb://localhost/students', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});
DB.then(() => {
    console.log('数据库连接成功');
}, () => {
    console.log('数据库连接失败');
});
const userSchema = new mongoose.Schema({
    uname: String,
    age: Number,
    gender: String,
    clazz: String
});
// 表名users注意
const User = mongoose.model('user', userSchema);
console.log(User);

// 查询数据
app.get('/', (req, res) => {
    User.find().then((result) => {
        console.log(result);
        studentObj = result
        ejs.renderFile('./view/index.ejs', studentObj, (err, str) => {
            if (err) {
                res.writeHead(500, {
                    'Content-Type': 'text/plain;charset="utf-8"'
                });
                res.end('500 - application ERROR');
                console.log(err);
            } else {
                res.writeHead(200, {
                    'Content-Type': 'text/html;charset="utf-8"'
                });
                res.end(str);
                res.render('index',{studentObj:result})
            }
        });
    })
})

app.post('/submit', (req, res) => {
    if (req.body) {
        const user = new User({
            uname: req.body.uname,
            age: req.body.age,
            gender: req.body.gender,
            clazz: req.body.clazz
        })
        user.save();
    };
    User.find().then((result) => {
        console.log(result);
        studentObj = result
        ejs.renderFile('./view/index.ejs', studentObj, (err, str) => {
            if (err) {
                res.writeHead(500, {
                    'Content-Type': 'text/plain;charset="utf-8"'
                });
                res.end('500 - application ERROR');
                console.log(err);
            } else {
                res.writeHead(200, {
                    'Content-Type': 'text/html;charset="utf-8"'
                });
                res.end(str);

            }
        });
    })
});
app.listen(3000, () => {
    console.log('3000端口开启');
});