const mongoose = require('mongoose');
const DB = mongoose.connect('mongodb://localhost/studentdb', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('成功');
}, () => {
    console.log('失败');
});