const mongoose = require('mongoose');
const userSchema = new mongoose.Schema({
    // clazz: String,
    // name: String,
    // age: Number,
    // tel: String,
    // address: String,
    // data: String,
    // remark: String,
    // gender: String,
    // hobby: String,
    // createtime: Date,
});

const User = mongoose.model('User', userSchema);
module.exports = User;