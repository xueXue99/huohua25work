const express = require('express');
const router = express.Router();
require('../db/db');
let User = require('../db/users');
//搜索
router.get('/getstudents', (req, res) => {
    console.log(req.query);
    if (req.query.name) {
        User.find(req.query.name).then((rel) => {
            res.send(rel);
        });
    } else {
        User.find().then((rel) => {
            res.send(rel);
        });
    };
});
//删除
router.get('/removeStudent', (req, res) => {
    User.deleteOne(req.query).then((rel) => {
        console.log(rel);
    });
});
//添加
router.post('/addStudent', (req, res) => {
    User.create(req.body).then((rel) => {
        console.log(rel);
    });
});
//修改
router.post('/updateStudent', (req, res) => {
    User.updateOne({ _id: req.body._id }, req.body).then((rel) => {
        console.log('成功');
    });
});
module.exports = router;