// 将对象转化为窗体格式
function dataFormatObj(obj) {
    if (!obj) {
        return '';
    };
    var arrtemp = [];
    // 遍历对象for...in
    for (var key in obj) {
        var value = obj[key].toString();
        arrtemp.push(key + '=' + value);
    };
    return arrtemp.join('&');
};

//get方式
function getfun(url, data, fun) {
    var xml = new XMLHttpRequest();
    xml.open('GET', url + '?' + dataFormatObj(data));
    xml.send();
    xml.onreadystatechange = function() {
        if (xml.readyState == 4) {
            if ((xml.status >= 200 && xml.status < 300) || xml.status == 304) {
                fun(xml)
            }
        };
    };
};
//POST方式
function postfun(url, data, fun) {
    var xml = new XMLHttpRequest();
    xml.open('POST', url);
    xml.setRequestHeader('Content-Type', 'application/json');
    xml.send(JSON.stringify(data));
    xml.onreadystatechange = function() {
        if (xml.readyState == 4) {
            if ((xml.status >= 200 && xml.status < 300) || xml.status == 304) {
                fun(xml)
            }
        };
    };
};