var tbody = document.querySelector('tbody');
// 进入页面时显示数据
var baseURL = 'http://localhost:3000/api/student/getstudents';
getfun(baseURL, '', fun1);

function fun1(xml) {
    var xmlObj = JSON.parse(xml.response);
    var nameArr = ['_id', 'clazz', 'name', 'gender', 'age', 'tel', 'hobby', 'address', 'remark', 'date'];
    for (var i = 0; i < xmlObj.length; i++) {
        var tr = document.createElement('tr');
        for (var j = 0; j < nameArr.length; j++) {
            var td = document.createElement('td');
            td.innerText = xmlObj[i][nameArr[j]];
            tr.appendChild(td);
        }
        var updateA = document.createElement('a');
        var deleteA = document.createElement('a');
        updateA.innerText = '修改';
        updateA.href = 'remove.html?_id=' + xmlObj[i]._id;
        deleteA.innerText = '删除';
        deleteA.href = '#';
        var td = document.createElement('td');
        td.appendChild(updateA);
        td.appendChild(deleteA);
        tr.appendChild(td);
        tbody.appendChild(tr);

        //删除按钮
        deleteA.onclick = function() {
            // 删除元素
            var flag = confirm('确定删除吗')
            if (flag) {
                this.parentElement.parentElement.remove();
                var baseURL = 'http://localhost:3000/api/student/removeStudent';
                var deleteId = this.parentElement.parentElement.firstElementChild.innerText;
                getfun(baseURL, { _id: deleteId }, function fun2() {});
            };
        };
    };
};


// 搜索按钮
var btn = document.querySelector('#btn');
var text = document.querySelector('#text');
btn.onclick = function() {
    var nameValue = text.value;
    tbody.innerHTML = '';
    getfun(baseURL, { name: nameValue }, fun1);
};