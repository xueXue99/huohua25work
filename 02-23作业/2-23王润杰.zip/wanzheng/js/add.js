var baseURL = 'http://localhost:3000/api/student/addStudent';
var genEles = document.querySelectorAll('.gen');
var genderEles = document.querySelectorAll('.gender');
var hobbyEles = document.querySelectorAll('.hobby');
var btn = document.querySelector('#save');
var addForm = document.querySelector('#add-form');
var valueObj = {};
btn.onclick = function(e) {
    // 其他
    for (var i = 0; i < genEles.length; i++) {
        valueObj[genEles[i].name] = genEles[i].value;
    };
    //性别
    for (var j = 0; j < genderEles.length; j++) {
        if (genderEles[j].checked) {
            valueObj[genderEles[j].name] = genderEles[j].value;
        };
    };
    //爱好
    var hobbyElesArr = [];
    for (var k = 0; k < hobbyEles.length; k++) {
        if (hobbyEles[k].checked) {
            hobbyElesArr.push(hobbyEles[k].value);
        };
    };
    valueObj.hobby = hobbyElesArr.join();
    postfun(baseURL, valueObj, function(xml) {
        location.href = location.origin + '/index.html';
    })
}