var baseURL = 'http://localhost:3000/api/student/getstudents';
var genEles = document.querySelectorAll('.gen');
var genderEles = document.querySelectorAll('.gender');
var hobbyEles = document.querySelectorAll('.hobby');
var btn = document.querySelector('#save');
var addForm = document.querySelector('#add-form');
var uId = location.search.split('=')[1];
getfun(baseURL, { '_id': uId }, function(xml) {
    var xmlObj = JSON.parse(xml.response)[0];
    console.log(xmlObj);
    for (var i = 0; i < genEles.length; i++) {
        genEles[i].value = xmlObj[genEles[i].name];
    };
    // 性别
    for (var j = 0; j < genderEles.length; j++) {
        if (genderEles[j].value == xmlObj.gender) {
            genderEles[j].checked = true;
        };
    };
    // 爱好
    for (var k = 0; k < hobbyEles.length; k++) {
        if (xmlObj.hobby.includes(hobbyEles[k].value)) {
            hobbyEles[k].checked = true;
        };
    };
});

btn.onclick = function(e) {
    var baseURL = 'http://localhost:3000/api/student/updateStudent';
    var valueObj = {};
    // 其他
    for (var i = 0; i < genEles.length; i++) {
        valueObj[genEles[i].name] = genEles[i].value;
    };
    //性别
    for (var j = 0; j < genderEles.length; j++) {
        if (genderEles[j].checked) {
            valueObj[genderEles[j].name] = genderEles[j].value;
        };
    };
    //爱好
    var hobbyElesArr = [];
    for (var k = 0; k < hobbyEles.length; k++) {
        if (hobbyEles[k].checked) {
            hobbyElesArr.push(hobbyEles[k].value);
        };
    };
    valueObj.hobby = hobbyElesArr.join();
    valueObj._id = uId;
    postfun(baseURL, valueObj, function(xml) {
        location.href = location.origin + '/index.html';
    })
}