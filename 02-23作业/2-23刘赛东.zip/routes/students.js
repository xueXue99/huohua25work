var express = require('express');
var router = express.Router();

// 引入连接数据库的代码
require('../db/db.js');
let userschma = require('../db/userschma');

// 查询学生
router.get('/getStudent', function(req, res) {
    userschma.find(req.query).then((data) => {
        res.status(200).send(data);
    });
});
// 删除
router.get('/removeStudent', function(req, res) {
    userschma.deleteOne(req.query).then((data) => {
        // console.log(req.query);
        console.log(data);
    });
});
// 添加
router.post('/addStudent', function(req, res) {
    userschma.create(req.body).then((rel) => {
        console.log(rel);
    });
});
// 修改
router.post('/updateStudent', function(req, res) {
    console.log(req.body);
    let id1 = req.body._id
    userschma.updateMany({ _id: id1 }, req.body).then((rel) => {
        console.log(rel);
    });
});
// module.exports 提供了暴露接口的方法
module.exports = router;