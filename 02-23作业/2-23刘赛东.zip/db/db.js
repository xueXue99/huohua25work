// 引用模块
let mongoose = require('mongoose');
// 链接数据库
let DB = mongoose.connect('mongodb://localhost/mongodemo', { useNewUrlParser: true, useUnifiedTopology: true });
// console.log(DB);
// 判断是否成功
DB.then(() => {
    console.log('成功');
}, () => {
    console.log('失败');
});