var osearch = document.querySelector('#search');
var btn = document.querySelector('#btn');
var otbody = document.querySelector('tbody');
var oMain = document.querySelector('.main');
var baseURL = 'http://localhost:3008';
btn.onclick = function () {
    oMain.style.display = 'block';
    if (osearch.value) {
        var stuValue = osearch.value.trim();
        getData(baseURL + '/api/student/getStudent', {
            name: stuValue
        }, showpage);
    } else {
        getData(baseURL + '/api/student/getStudent', '', showpage);
    }
}

function showpage(xhrobj) {
    var arrSearch = JSON.parse(xhrobj.responseText);
    var xhrList = '';
    for (var i = 0; i < arrSearch.length; i++) {
        xhrList += "<tr><td>" + arrSearch[i]._id + "</td><td>" + arrSearch[i].clazz +
            "</td><td>" + arrSearch[i].name + "</td><td>" + arrSearch[i].gender +
            "</td><td>" + arrSearch[i].age + "</td><td>" + arrSearch[i].tel +
            "</td><td>" + arrSearch[i].hobby + "</td><td>" + arrSearch[i].address +
            "</td><td>" + arrSearch[i].remark + "</td><td>" + arrSearch[i].date+
            "<td><a href='#' class='modify'>修改</a>" + '   ' +
            "<a href='' class='del'>删除</a></td></tr>";
    };
    if (!xhrList) {
        xhrList = '<tr><td colspan="11">' + '查无此人,请确认姓名是否正确' + '</td></tr>';
    };
    otbody.innerHTML = xhrList;
    var del = document.querySelectorAll('.del');
    for (i = 0; i < del.length; i++) {
        del[i].onclick = function (e) {
            var delId = e.target.parentNode.parentNode.firstElementChild.innerHTML;
            console.log(delId );
            alert('是否确认删除')
            e.target.parentNode.parentNode.parentNode.removeChild(e.target.parentNode.parentNode);
            delData(baseURL+'/api/student/removeStudent',{id:delId})

            if (otbody.children.length == 0) {
                oMain.style.display = 'none';
            }
                 e.preventDefault();

        }
    }
    var modify=document.querySelectorAll('.modify');
    for (var j=0;j<modify.length;j++){
        modify[j].onclick = function() {
            location.href='./page/update.html'
            localStorage.setItem('studId',this.parentNode.parentNode.firstElementChild.innerHTML);
        }
        
    }
}

