var clandan=document.querySelectorAll('.clandan');
var gender=document.querySelectorAll('.gender');
var hobbies=document.querySelectorAll('.hobbies');
var formIfon=document.querySelector('#formIfon');
var age=document.querySelector('#age');
age.onblur=function(){
    if((age.value<0)||(age.value>200)){
       alert('年龄输入格式不正确,请输入正确的年龄');
       age.value='';
    }
}
var baseURL='http://localhost:3008';
var studIfon={};
formIfon.onsubmit=function(e){


    for (var i=0;i<clandan.length;i++){
        studIfon[clandan[i].name]=clandan[i].value;
    }
    console.log(studIfon);
for (var j = 0; j < gender.length; j++) {
    if (gender[j].checked) {
        studIfon.gender = gender[j].value;
        break;
    };
};    

var tempHobby = [];
for (var k = 0; k < hobbies.length; k++) { 
    if (hobbies[k].checked) {
        console.log(hobbies[k].value);
        tempHobby.push(hobbies[k].value);
    }
    console.log(tempHobby);
};
studIfon.hobby=tempHobby;
console.log(studIfon);


postData(baseURL+'/api/student/addStudent',studIfon,function(){
    location.href ='../studentSystem.html';
});
e.preventDefault();
}