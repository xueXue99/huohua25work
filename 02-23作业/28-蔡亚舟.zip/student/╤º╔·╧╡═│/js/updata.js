var clandan=document.querySelectorAll('.clandan');
var gender=document.querySelectorAll('.gender');
var hobbies=document.querySelectorAll('.hobbies');
var formUpdate=document.querySelector('#formUpdate');
var age=document.querySelector('#age');
age.onblur=function(){
    if((age.value<0)||(age.value>200)){
       alert('年龄输入格式不正确,请输入正确的年龄');
       age.value='';
    }
}
var baseURL='http://localhost:3008';
var studUpdateId=localStorage.getItem('studId');
console.log(studUpdateId);
getData(baseURL + '/api/student/getStudent', { id: studUpdateId }, function(xhr) {
    var studUpdateObj = JSON.parse(xhr.responseText)[0];
    console.log(studUpdateObj);
    console.log(studUpdateId);
    for (var i = 0; i < clandan.length; i++) {
        clandan[i].value = studUpdateObj[clandan[i].name];
    };
    // 性别的信息的设置
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].value == studUpdateObj.gender) {
            gender[j].checked = true;
        };
    };
    // 爱好的设置
    for (var k = 0; k < hobbies.length; k++) {
        if (studUpdateObj.hobby.includes(hobbies[k].value)) {
            hobbies[k].checked = true;
        };
    };
});

var studIfon={};
formUpdate.onsubmit=function(e){
console.log(1);

    for (var i=0;i<clandan.length;i++){
        studIfon[clandan[i].name]=clandan[i].value;
    }
for (var j = 0; j < gender.length; j++) {
    if (gender[j].checked) {
        studIfon.gender = gender[j].value;
        break;
    };
};   

var tempHobby = [];
for (var k = 0; k < hobbies.length; k++) { 
    if (hobbies[k].checked) {
        tempHobby.push(hobbies[k].value);
    }
};
studIfon.hobby=tempHobby.join();
studIfon._id = studUpdateId;
postData(baseURL+'/api/student/updateStudent',studIfon,function(){
    location.href ='../studentSystem.html';
});
e.preventDefault();
}