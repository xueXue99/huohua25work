// 获取服务器的数据
function getData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url + '?' + dataFormatobj(data));
    xhr.send();
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr)
        };
    };
};



function dataFormatobj(obj) {
    if (!obj) {
        return;
    };
    var arrtemp = []
    for (var key in obj) {
        var value = obj[key].toString();
        arrtemp.push(key + '=' + value)
    }
    return arrtemp.join('&');
}
// 添加
function postData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.setRequestHeader('Content-Type', 'application/json')
    var dataJson = JSON.stringify(data);
    xhr.send(dataJson);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr)
        };
    };
};
// 删除
function delData(url, data) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url + '?' + dataFormatobj(data));
    xhr.send();
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
        };
    };
};
// 修改
function upData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.setRequestHeader('Content-Type', 'application/json')
    var dataJson = JSON.stringify(data);
    xhr.send(dataJson);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr)
        };
    };
};