// 引入模块
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
// 静态资源
app.use(express.static(__dirname));
// post参数

app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());

// 解决跨域
app.use(cors());

app.use('/api/student', require('./routes/admin.js'));

app.listen(3008, () => {
    console.log('3008端口开启');
})