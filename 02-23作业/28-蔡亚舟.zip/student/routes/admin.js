// 引入模块
const express = require('express');
const router = express.Router();


require('../DB/db.js')
let userSchema = require('../DB/userschema.js')

// 查询信息
router.get('/getStudent', function (req, res) {
    let thisname = req.query.name;
    let thisid = req.query.id;
    console.log(thisid);
    console.log(thisname);
    if (thisname) {
        userSchema.find({
            name: RegExp(thisname)
        }).then((data) => {
            res.status(200).send(data);
        });
    } else if (thisid) {
        userSchema.find({
            _id: thisid
        }).then((data) => {
            res.status(200).send(data);
        });
    } else {
        userSchema.find().then((data) => {
            res.status(200).send(data);
        });
    }
})

// 删除信息
router.get('/removeStudent', function (req, res) {
    let thisid = req.query.id
    userSchema.deleteOne({
        _id: thisid
    }).then((res, req) => {
        console.log(res);
    })
})
// 添加信息
router.post('/addStudent', function (req, res) {
    console.log(req.body);
    userSchema.create({
        name: req.body.name,
        clazz: req.body.clazz,
        age: req.body.age,
        tel: req.body.tel,
        address: req.body.address,
        date: req.body.date,
        remark: req.body.remark,
        gender: req.body.gender,
        hobby: req.body.hobby
    })
    // res.send()
})
// 修改信息
router.post('/updateStudent', function (req, res) {
    console.log(req.body._id);
    userSchema.updateOne({
        _id: req.body._id
    }, req.body).then((rel) => {
        console.log(rel);
    })
    res.send()                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
}) 
module.exports = router