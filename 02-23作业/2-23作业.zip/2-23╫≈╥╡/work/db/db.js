const mongoose = require('mongoose');
let DB = mongoose.connect('mongodb://localhost/fdy', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('连接成功');
}, () => {
    console.log('连接失败');
});