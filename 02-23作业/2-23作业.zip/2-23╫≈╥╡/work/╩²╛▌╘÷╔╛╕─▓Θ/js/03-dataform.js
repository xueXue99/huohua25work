var form1 = document.querySelector('#form1'); //表单
var getdata = document.querySelectorAll('.getdata'); //表单控件
var gender = document.querySelectorAll('.gender'); //性别
var hobbies = document.querySelectorAll('.hobby');
var dataObj = {}; //存放表单数据的对象
var dataarr = []; //存放多选的数据数组
form1.onsubmit = function(e) {
    //获取数据
    for (var i = 0; i < getdata.length; i++) {
        dataObj[getdata[i].name] = getdata[i].value;
    };
    //获取单选数据
    for (var i = 0; i < gender.length; i++) {
        if (gender[i].checked) { //被选中的单选
            dataObj[gender[i].name] = gender[i].value;
        };
    };
    //获取多选数据
    for (var i = 0; i < hobbies.length; i++) {
        if (hobbies[i].checked) {
            dataarr.push(hobbies[i].value); //如果多选别选中，将值存放在数组
        };
    };
    //将数组转化为字符串
    dataarr = dataarr.toString();
    console.log(dataarr);
    //将数组数据存放在对象
    dataObj.hobby = dataarr;
    var baseURL = 'http://localhost:3008'; //基础的URL
    xhrPost(baseURL + '/api/student/addStudent', dataObj, function() {
        console.log(location.origin);
        location.href = location.origin + '/01-index.html'; //跳转到源页面
    });
    e.preventDefault(); //阻止刷新
};