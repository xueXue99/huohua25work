//获取表单元素
var form2 = document.querySelector('#form2');
//获取输入框
var getdata = document.querySelectorAll('.getdata');
//获取性别框
var gender = document.querySelectorAll('.gender');
//获取爱好
var hobby = document.querySelectorAll('.hobby');
// 设置页面id
var updataid = location.search.split('=')[1];
//获取后台数据
var baseURL = 'http://localhost:3008'; //基础的URL
xhrGet(baseURL, { id: updataid }, function(xhr) {
    var dataObj = JSON.parse(xhr.responseText)[0];
    //获取数据到表单
    for (var i = 0; i < getdata.length; i++) {
        getdata[i].value = dataObj[getdata[i].name];
    };
    //性别
    for (var i = 0; i < gender.length; i++) {
        if (gender[i].value == dataObj.gender) { //性别的值等于后台数据
            gender[i].checked = true;
        };
    };
    //爱好
    for (var i = 0; i < hobby.length; i++) {
        if (dataObj.hobby.includes(hobby[i].value)) {
            hobby[i].checked = true;
        };
    }
});
//提交数据
var dataObj = {}; //存放表单数据的对象
var dataarr = []; //存放多选的数据数组
form2.onsubmit = function(e) {
    //获取数据
    for (var i = 0; i < getdata.length; i++) {
        dataObj[getdata[i].name] = getdata[i].value;
    };
    //获取单选数据
    for (var i = 0; i < gender.length; i++) {
        if (gender[i].checked) { //被选中的单选
            dataObj[gender[i].name] = gender[i].value;
        };
    };
    //获取多选数据
    for (var i = 0; i < hobby.length; i++) {
        if (hobby[i].checked) {
            dataarr.push(hobby[i].value); //如果多选别选中，将值存放在数组
        };
    };
    //将数组转化为字符串
    dataarr = dataarr.toString();
    //将数组数据存放在对象
    dataObj.hobby = dataarr;
    //设置id
    dataObj.id = updataid;
    var baseURL = 'http://localhost:3008'; //基础的URL
    xhrPost(baseURL + '/api/student/updateStudent', dataObj, function() {
        console.log(location.origin);
        location.href = location.origin + '/01-index.html'; //跳转到源页面
    });
    e.preventDefault(); //阻止刷新
};