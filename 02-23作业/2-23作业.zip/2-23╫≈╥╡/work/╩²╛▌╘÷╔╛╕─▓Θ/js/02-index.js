var tbodyEle = document.querySelector('tbody');
var baseURL = 'http://localhost:3008'; //基础的URL
xhrGet(baseURL, '', strConcat);

//拼串封装函数
function strConcat(xhr) {
    var data = xhr.responseText;
    data = JSON.parse(data); //后台数据装换成对象
    var dataRel = ''; //拼串
    for (var i = 0; i < data.length; i++) {
        dataRel += '<tr><td>' + data[i].id + '</td>' + '<td>' + data[i].clazz + '</td>' + '<td>' + data[i].name + '</td>' + '<td>' + data[i].gender + '</td>' + '<td>' + data[i].age + '</td>' + '<td>' + data[i].tel + '</td>' + '<td>' + data[i].hobby + '</td>' + '<td>' + data[i].address + '</td>' + '<td>' + data[i].remark + '</td>' + '<td>' + data[i].date + '</td>' + '<td><a href="03-updataform.html?id=' + data[i].id + '"class="changebtn" id="' + data[i].id + '">修改</a>&emsp;<a href="javascript:;" class="removebtn">删除</a></td></tr>';
    };
    if (dataRel) {
        tbodyEle.innerHTML = dataRel;
    } else {
        dataRel = '<tr><td colspan="11">输入数据不正确呀！</td></tr>';
        tbodyEle.innerHTML = dataRel;
    };

    //删除按钮
    var removebtn = document.querySelectorAll('.removebtn');
    delbtn(removebtn);
};

function delbtn(removebtn) {
    //删除按钮
    for (var i = 0; i < removebtn.length; i++) {
        removebtn[i].onclick = function() {
            var removeEle = this.parentNode.parentNode.firstElementChild.innerHTML;
            console.log(removeEle); //id值
            this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode); //删除元素
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'http://localhost:3008/api/student/removeStudent?id=' + removeEle); //删除后台数据
            xhr.send(null);
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4) {
                    if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304) {
                        console.log(xhr.response);
                    };
                };
            };
        };
    };
}

//搜索按钮
var searchipt = document.querySelector('#searchipt');
var searchbtn = document.querySelector('#searchbtn');
searchbtn.onclick = function() {
    var searchiptVal = searchipt.value; //输入框值
    if (searchiptVal == '') {
        alert('请输入内容呀！');
    } else {
        xhrGet(baseURL, { name: searchiptVal }, strConcat);
        searchipt.value = '';
    };
};