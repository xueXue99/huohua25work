//获取后台数据函数，get方式
function xhrGet(url, data, func) {
    var xhr = new XMLHttpRequest();
    var getURL = url + '/api/student/getStudent';
    //设置请求方式与url
    xhr.open('GET', getURL + '?' + funURL(data));
    //发送请求
    xhr.send(null);
    //监听状态
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304) {
                // console.log(xhr);
                func(xhr);
            };
        };
    };
};

//URL的封装函数
function funURL(obj) {
    var arr = [];
    if (!obj) {
        return;
    };
    for (var k in obj) {
        var objVal = obj[k].toString();
        arr.push(k + '=' + objVal);
    };
    return arr.join('&'); //返回数组转化为的字符串
}

//获取后台数据函数，post方式
function xhrPost(url, data, func) {
    var xhr = new XMLHttpRequest();
    //设置请求方式与url
    xhr.open('POST', url);
    //设置请求头部，json格式
    xhr.setRequestHeader('Content-Type', 'application/json');
    //将数据转换为json
    var datajson = JSON.stringify(data);
    //发送请求
    xhr.send(datajson);
    //监听状态
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304) {
                func(xhr);
            };
        };
    };
};