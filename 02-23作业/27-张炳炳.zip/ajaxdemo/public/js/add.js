var oAddForm = document.getElementById('add_form');
var oStudInfo = document.querySelectorAll('.stud_info');
oAddForm.onsubmit = function(e) {

    var studentsObj = {};
    // 获取可以直接取得value值的学生信息
    for (var i = 0; i < oStudInfo.length; i++) {
        studentsObj[oStudInfo[i].name] = oStudInfo[i].value;
    }
    // 获取性别
    var oGender = document.querySelectorAll('[name="gender"]');
    for (var i = 0; i < oGender.length; i++) {
        if (oGender[i].checked) {
            studentsObj[oGender[i].name] = oGender[i].value;
            break;
        }
    }
    // 获取爱好
    var oHobby = document.querySelectorAll('[name="hobby"]');
    var arrHabby = [];
    for (var i = 0; i < oHobby.length; i++) {
        if (oHobby[i].checked) {
            arrHabby.push(oHobby[i].value);
        }
        studentsObj[oHobby[i].name] = arrHabby;

    };
    postData(dataUrl + '/api/student/addStudents', JSON.stringify(studentsObj), function() {
        // 打开后台服务器，文件在本地服务器打开
        // location.origin 返回协议 域名 端口号
        location.href = location.origin + '/index.html';
        // location.href = 'file:///E:/Web%E5%89%8D%E7%AB%AF/Web%E5%89%8D%E7%AB%AF/AJAX/03-ajax/%E4%BD%9C%E4%B8%9A/index.html';
    });
    e.preventDefault();
};