var stuUpdata = location.search.split('=')[1];
var obj2 = {
    _id: stuUpdata
}
var oUpdataForm = document.getElementById('updata_form');
var oStudInfo = document.querySelectorAll('.stud_info');
var oGender = document.querySelectorAll('[name="gender"]');
var oHobby = document.querySelectorAll('[name = "hobby"]');
getData(dataUrl + '/api/student/getStudents', obj2, function(xhr) {
    var studUpdateObj = JSON.parse(xhr.responseText)[0];
    for (var i = 0; i < oStudInfo.length; i++) {
        oStudInfo[i].value = studUpdateObj[oStudInfo[i].name];
    };
    for (var i = 0; i < oGender.length; i++) {
        if (oGender[i].value == studUpdateObj[oGender[i].name]) {
            oGender[i].checked = true;
        }
    };
    for (var i = 0; i < oHobby.length; i++) {
        if (studUpdateObj.hobby.indexOf(oHobby[i].value) !== -1) {
            oHobby[i].checked = true;
        };
    };
});
oUpdataForm.onsubmit = function(e) {
    var studentsObj = {};
    // 获取可以直接取得value值的学生信息
    for (var i = 0; i < oStudInfo.length; i++) {
        studentsObj[oStudInfo[i].name] = oStudInfo[i].value;
    }
    // 获取性别
    // var oGender = document.querySelectorAll('[name="gender"]');
    for (var i = 0; i < oGender.length; i++) {
        if (oGender[i].checked) {
            studentsObj[oGender[i].name] = oGender[i].value;
            break;
        }
    }
    // 获取爱好
    // var oHobby = document.querySelectorAll('[name="hobby"]');
    var arrHabby = [];
    for (var i = 0; i < oHobby.length; i++) {
        if (oHobby[i].checked) {
            arrHabby.push(oHobby[i].value);
        }
        studentsObj[oHobby[i].name] = arrHabby;
    };
    studentsObj._id = stuUpdata;
    postData(dataUrl + '/api/student/alterStudents', JSON.stringify(studentsObj), function() {
        // 打开后台服务器，文件在本地服务器打开
        // location.origin 返回协议 域名 端口号
        location.href = location.origin + '/index.html';
        // location.href = 'http://127.0.0.1:5500/AJAX/03-ajax--/%E4%BD%9C%E4%B8%9A%EF%BC%88%E5%AE%8C%E6%95%B4%E7%89%88%EF%BC%89/index.html';
    });
    e.preventDefault();
};