// 引入express模块
const express = require('express');
// 引入body-parser模块--获取post请求数据
const bodyParser = require('body-parser');
// 引入cors模块--解决ajax的跨域问题
const cors = require('cors');

// 创建服务
const app = express();
// 解决跨域问题
app.use(cors());
// 托管静态资源
app.use(express.static(__dirname));
// 设置数据格式
// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());

// 设置一级路由
app.use('/api/student', require('./routes/resStudents'));

// 监听端口号
app.listen(3008, () => {
    console.log('服务器已开启,端口号:3008');
});