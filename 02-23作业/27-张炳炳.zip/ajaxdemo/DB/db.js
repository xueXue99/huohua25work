// 1.引入mongoose模块
const mongoose = require('mongoose');
// 连接数据库
const DB = mongoose.connect('mongodb://localhost:/studentsData', { useNewUrlParser: true, useUnifiedTopology: true });
// 监听数据库连接状态
DB.then(() => {
    console.log('数据库连接成功');
}, () => {
    console.log('数据库连接失败');
});