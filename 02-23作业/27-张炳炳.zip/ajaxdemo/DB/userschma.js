// 1.引入mongoose模块
const mongoose = require('mongoose');

// 创建集合规则
const userSchema = new mongoose.Schema({
    name: {
        // 定义数据类型
        type: String,
        required: [true, '姓名不能为空'],
        minlength: [2, '姓名不能小于2位'],
        maxlength: [4, '姓名不能大于4位'],
        // 过滤空格
        trim: true
    },
    clazz: {
        type: String
    },
    tel: {
        type: Number
    },
    hobby: {
        type: Array
    },
    address: {
        type: String
    },
    remark: {
        type: String
    },
    date: {
        // type: Date,
        // default: Date.now
        // Type: String
    },
    age: {
        type: Number,
        min: [1, '年龄不能小于1'],
        max: [130, '年龄不能大于130']
    },
    gender: {
        type: String,
        enum: ['男', '女']
    }
    // createtime: {
    //     type: Date,
    //     default: Date.now
    // }
});

// 利用规则创建集合
const User = mongoose.model('User', userSchema);
// 暴露User
module.exports = User;