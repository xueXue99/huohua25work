// 引入express模块
const express = require('express');
// 引入body-parser模块--获取post请求数据
const bodyParser = require('body-parser');
const app = express();
// 设置数据格式
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// 创建路由容器
const router = express.Router();
// 引入数据库操作
require('../DB/db');
let User = require('../DB/userschma');

// 增加学生信息
router.post('/addStudents', (req, res) => {
    // 获取传输来的数据
    let studentsdata = req.body;
    // 转换为JSON格式
    // studentsdata = JSON.parse(studentsdata);
    // 添加到数据库中
    User.create(studentsdata).then(() => {
        // 成功时进行响应
        res.send(200, '添加成功');
    });
});
// 删除学生信息
router.get('/removeStudents', (req, res) => {
    // // 获取要删除的学生信息的id或者姓名
    let thisid = req.query._id;
    // let thisuname = req.query.name;
    // // 判断id是否存在
    // if (thisid) {
    //     // 判断uname是否存在
    //     if (thisuname) {
    //         // 根据传递的id和姓名删除学生数据
    //         User.deleteMany({ name: thisuname, _id: thisid });
    //     } else {
    //         // 根据传递的id删除学生数据
    //         User.deleteMany({ _id: thisid });
    //     };
    // } else if (thisuname) {
    //     // 根据传递的姓名传递数据
    //     User.deleteMany({ name: thisuname });
    // };
    User.deleteMany({ _id: thisid }).then((rel) => {
        // 成功时响应
        res.status(200).send("ok");
    });
});

// 修改学生信息
router.post('/alterStudents', (req, res) => {
    // 获取修改后的学生信息
    let studentdata = req.body;
    // 根据id修改数据库中学生信息
    User.updateMany({ _id: studentdata._id }, studentdata).then(() => {
        // 成功时响应
        res.send(200, '修改成功');
    });
});

// 查询学生信息
router.get('/getStudents', (req, res) => {
    // 获取传递的信息
    let thisid = req.query._id;
    let thisuname = req.query.name;

    if (thisid) {
        User.find({ _id: thisid }).then((result) => {
            res.status(200).send(result);
        });
    } else if (thisuname) {
        User.find({ name: thisuname }).then((result) => {
            res.status(200).send(result);
        });
    } else {
        User.find().then((result) => {
            res.status(200).send(result);
        });
    };
});


// 暴露接口
module.exports = router;