const fs = require('fs');
function remF(dir) {
    let files = fs.readdirSync(dir);
    console.log(files);
    for (let i = 0; i < files.length; i++) {
        let fileDir = dir + '/' + files[i];
        let rel = fs.statSync(fileDir);
        if (rel.isFile()) {
            fs.unlinkSync(fileDir)
        } else {
            remF(fileDir);
        }
    }
    fs.rmdirSync(dir);
}
remF('test');