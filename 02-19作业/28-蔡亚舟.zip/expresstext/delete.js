const fs = require('fs');

function del(path) {
    let files = fs.readdirSync(path)
    files.forEach(function (file) {
        var nePath = path + "/" + file;
        if (fs.statSync(nePath).isDirectory()) {
            del(nePath)
        } else {
            fs.unlinkSync(nePath);
        }
    })
    fs.rmdirSync(path)
}
del('./files')