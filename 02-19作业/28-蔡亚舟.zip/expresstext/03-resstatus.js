const express=require('express');
const app=express();
app.get("/gets",(req,res,next)=>{
    console.log(req.query.name);
    req.name=req.query.name
    next()
})
app.get("/gets",(req,res)=>{
    res.send(req.name)
})
app.listen(3000,()=>{
    console.log('3000开启');
})