const express = require('express');
const app = express();
app.use((req, res, next) => {
    console.log(req.url);
    next();
});
app.get('/login', (req, res) => {
    console.log(req.query);
    res.status(200).send(req.query)
})
app.get('/find/:id', (req, res) => {
    console.log(req.params);
    console.log(req.params.id);
    res.status(200).send(req.params)
})
app.get('/user/:uid/photo/:files', (req,res) => {
    res.status(200).send(req.params)
})
app.listen(3000,()=>{
    console.log('3000开启');
})