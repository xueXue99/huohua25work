const express = require('express');
const app = express();
app.use((req, res, next) => {
    if (req.url == '/gets') {
        next()
    } else {
        res.status(404).send('resoure is not find')
    }
})
app.use('/gets', (req,res) => {
    res.send('资源找到')
})
app.listen(3000,()=>{
    console.log('3000开启');
})