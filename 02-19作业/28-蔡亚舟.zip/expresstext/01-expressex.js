// 引入express框架
const express=require('express');
// 生成express实例app
const app=express();

app.get("/",(req,res)=>{
    res.send('hello world')
});
app.listen(3000,()=>{
    console.log('3000端口已开放');
})