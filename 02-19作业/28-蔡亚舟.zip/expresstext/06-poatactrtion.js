const express=require('express');
const app=express();
const bodyParser=require('body-parser');
// 设置静态资源
app.use(express.static(__dirname));
// 配置post请求的参数
// extended;flase:参数时键值对的数据为String或者是Array
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
// 解决跨域
app.use((req,res,next)=>{
    res.header('Access-Control-Allow-Origin','*');
    res.header('Access-Control-Allow-Methods','GET,POST,DELETE, OPTIONS');
    res.header('Access-Control-Allow_header','X-Requested-With');
    res.header('Access-Control-Allow_header','Content-Type');
    res.header('Content-Type','application/json');
    next();
})
// 设置post请求
app.post('/addstudent',(req,res)=>{
    console.log(req.body);
    res.status(200).send(req.body)
})
app.listen(3000,()=>{
    console.log('3000开启');
})
