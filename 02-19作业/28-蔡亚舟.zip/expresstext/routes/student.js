const express = require('express');
const app = express();
const fs = require('fs');
const bodyParser = require('body-parser');
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,DELETE, OPTIONS');
    res.header('Access-Control-Allow_header', 'X-Requested-With');
    res.header('Access-Control-Allow_header', 'Content-Type');
    res.header('Content-Type', 'application/json');
    next();
});

app.get('/getStudent', (req, res) => {
    fs.readFile(__dirname + './../data/student.json', 'utf-8', (err, data) => {
        if (err) {
            console.log(err);
        } else {
            var datas = JSON.parse(data)
            console.log(datas);
            res.status(200).send(datas)
        }
    })
})

app.post('/addstudent', (req, res) => {
    console.log(req.body);
    res.status(200).send(req.body);
    var str = JSON.stringify(req.body)
    fs.appendFile(__dirname + './../data/student.json', str, (err) => {
        if (err) {
            console.log(err);
        } else {
            console.log('追加成功');
        }
    });
});
app.listen(3000, () => {
    console.log('3000开启');
})