// 引入express
const express = require('express');
const app = express();
app.get("/", (req, res) => {
    res.send('hello express')
})
app.get("/getstudent",(req,res)=>{
    console.log(req.query);
    res.send(req.query)
})
app.listen(3000,()=>{
    console.log('3000开启');
})