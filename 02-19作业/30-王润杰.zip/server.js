const fs = require('fs');
const express = require('express');
const bodyParser = require('body-parser');
const e = require('express');
const app = express();
app.use(express.static(__dirname))
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Content-Type', 'application/json');
    next();
});
app.get('/api/student/getstudent', (req, res) => {
    fs.readFile('./data/data.json', 'utf-8', (err, data) => {
        if (err) {
            console.log(err);
            res.send(data);
        } else {
            console.log(data);
            res.send(data);
        }
    });
});
app.post('/api/student/addstudent', (req, res) => {
    let con = req.body;
    fs.readFile('./data/data.json', 'utf-8', (err, data) => {
        if (err) {
            console.log(err);
        } else {
            let newData = JSON.parse(data);
            newData.push(con);
            fs.writeFileSync('./data/data.json', JSON.stringify(newData, null, 4), (err) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log('成功');
                };
            });
        };
    });
    res.send();
});




app.listen(3000, () => {
    console.log(3000);
});