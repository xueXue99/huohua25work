const fsExtra = require('fs-extra');
fsExtra.remove('./01', err => {
    if (err) {
        console.log(err);
    } else {
        console.log('删除成功');
    };
});