var dataUrl = 'http://localhost:3000';
// GET请求
function getData(url, obj, fun) {
    // 创建XMLHttpRequest对象
    var xhr = new XMLHttpRequest();
    // 发送请求
    xhr.open('GET', url + '?' + dataFormatObj(obj));
    // 设置请求头（get不需要）
    // 发送请求
    xhr.send();
    // 监听状态改变事件
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        }
    }
};
// 将对象转换为窗体格式
function dataFormatObj(obj) {
    if (!obj) {
        return;
    }
    var arrtemp = [];
    for (var key in obj) {
        var value = obj[key].toString();
        arrtemp.push(key + '=' + value);
    }
    return arrtemp.join('&');
};

// post请求
function postData(url, data, fun) {
    // 创建XMLHttpRequest对象
    var xhr = new XMLHttpRequest();
    // 发送请求
    xhr.open('POST', url);
    // 设置请求头
    xhr.setRequestHeader('Content-Type', 'application/json');
    // 发送请求
    xhr.send(data);
    // 监听状态改变事件
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        }
    }
};