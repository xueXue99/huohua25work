var oTbodyStu = document.getElementById('tbody_stu');

getData(dataUrl + '/api/student/getStudent', {}, showPage);

function showPage(xhr) {
    var studentData = JSON.parse(xhr.responseText);
    var students = '';
    for (var i = 0; i < studentData.length; i++) {
        students += `<tr>
        <td>${studentData[i].id}</td>
        <td>${studentData[i].clazz}</td>
        <td>${studentData[i].name}</td>
        <td>${studentData[i].gender}</td>
        <td>${studentData[i].age}</td>
        <td>${studentData[i].tel}</td>
        <td>${studentData[i].hobby}</td>
        <td>${studentData[i].address}</td>
        <td>${studentData[i].remark}</td>
        <td>${studentData[i].date}</td>
        <td><a href="page/updata.html?id=${studentData[i].id}" class = "modify">修改</a><a href="javascript:void(0)" data-std-id =${studentData[i].id}  class = "student_del">删除</a></td>
    </tr>`;
    }
    if (!students) {
        students = `<tr><td colspan = '11>检索不到数据</td></tr>`
    }
    oTbodyStu.innerHTML = students;

};
// 搜索
var oSearchBtn = document.getElementById('search_btn');
var oSearch = document.getElementById('search');
oSearchBtn.onclick = function() {
    // trim()去掉字符串两端多余的空格
    var oSearchValue = oSearch.value.trim();
    var obj = {
        name: oSearchValue
    }
    getData(dataUrl + '/api/student/getStudent', obj, showPage);
    // 点击搜索后清空搜索框
    oSearch.value = '';
}