// 引入express框架
const express = require('express');
// 引入bodyParser
const bodyParser = require('body-parser');
// 引入fs模块
const fs = require('fs');
// 创建服务器
const app = express();
app.use(express.static(__dirname));
// 配置post请求的参数
// extended:false  --参数是键值对的数据为String或者说Srray
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// 跨域请求
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Content-Type', 'application/json');
    next();
});

app.use('/api/student', require('./routes/students'));


// 监听端口
app.listen(3000, () => {
    console.log('服务器已开启');
});