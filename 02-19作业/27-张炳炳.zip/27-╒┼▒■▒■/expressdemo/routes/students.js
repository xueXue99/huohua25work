const express = require('express');

const fs = require('fs');

const router = express.Router();
// 搜索
router.get('/getStudent', (req, res) => {
    fs.readFile(__dirname + './../data/students.json', 'utf-8', (err, data) => {
        if (err) {
            res.status(500).end();
            return console.log(err);
        } else {
            data = JSON.parse(data);
            let results = [];
            // 接收到的参数id
            let myid = req.query.id;
            // 接收到的参数uname
            let myname = req.query.name;
            if (myid) {
                data.forEach((item) => {
                    if (item.id == myid) {
                        results.push(item);
                    };
                });
            } else if (myname) {
                data.forEach((item) => {
                    if (item.uname == myname) {
                        results.push(item);
                    };
                });
            } else {
                results = data;
            };
            console.log(results);
            res.send(200, results);
        };
    });
});

// 添加
router.post('/addStudent', (req, res) => {
    fs.readFile(__dirname + './../data/students.json', 'utf-8', (err, data) => {
        console.log(req.body);
        if (err) {
            res.status(500).end();
            return console.log(err);
        } else {
            data = JSON.parse(data);
        };
        // 将添加时间作为id
        req.body.id = Date.now().toString();
        // 将新添加的信息加入到数组中
        data.push(req.body);

        fs.writeFile(__dirname + './../data/students.json', JSON.stringify(data), (err) => {
            if (err) {
                res.status(500).end();
                return console.log(err);
            };
            res.status(200).send(data);
        });
    });

});

// 暴露接口
module.exports = router;