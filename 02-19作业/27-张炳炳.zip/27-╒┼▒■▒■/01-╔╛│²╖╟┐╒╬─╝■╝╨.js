// 引入fs模块
const fs = require('fs');

function delDir(url) {
    // fs.readdirSync()同步读取目录的内容
    let list = fs.readdirSync(url);
    list.forEach((value, index) => {
        let newUrl = url + '/' + value;
        // 读取文件信息
        let stats = fs.statSync(newUrl);
        // 判断是文件还是文件夹
        if (stats.isFile()) {
            // 是文件,删除
            fs.unlinkSync(newUrl);
        } else {
            delDir(newUrl);
        };
        // if (stats.isDirectory()) {
        //     delDir(newUrl);
        // } else {
        //     fs.unlinkSync(newUrl);
        // }
    });
    // 删除文件夹
    fs.rmdirSync(url);
}
delDir('./test');