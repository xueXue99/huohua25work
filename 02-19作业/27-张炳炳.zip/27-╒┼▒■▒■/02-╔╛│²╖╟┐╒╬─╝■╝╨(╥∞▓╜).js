// 引入fs模块
const fs = require('fs');

function delDir(url) {
    fs.readdir(url, (err, files) => {
        if (err) {
            console.log(err);
        } else {
            console.log(files);
            files.forEach((value) => {
                let newUrl = url + '/' + value;
                console.log(newUrl);
                fs.stat(newUrl, (err, stats) => {
                    if (err) {
                        console.log(err);
                    } else {
                        if (stats.isFile()) {
                            console.log(111);
                            fs.unlink(newUrl, (err) => {
                                if (err) {
                                    console.log(err);
                                }
                            });
                        } else {
                            delDir(newUrl);
                        };
                        fs.rmdir(url, (err) => {
                            if (err) {
                                console.log(err);
                            }
                        });
                    }
                });

            });

        }
    });

}
delDir('./test');