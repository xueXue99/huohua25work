// let fs = require('fs');

// function fss(date) {
//     fs.readdirSync(date).forEach(function(i) {
//         var path = date + '/' + i;
//         if (fs.statSync(path).isDirectory()) {
//             fss(path);
//         } else {
//             fs.unlinkSync(path)
//         };
//     });
//     fs.rmdirSync(date);
// };
// fss(__dirname + '/' + '222');
// console.log(fss(__dirname + '/' + '222'));
// console.log(__dirname + '/222');


let fs = require('fs');

function fun(date) {
    fs.readdirSync(date).forEach(function(i) {
        let fss = (date + '/' + i)
        if (fs.statSync(fss).isDirectory()) {
            fun(fss)
        } else {
            fs.unlinkSync(fss);
        };
    });
    fs.rmdirSync(date)
}
fun(__dirname + '/' + '222')