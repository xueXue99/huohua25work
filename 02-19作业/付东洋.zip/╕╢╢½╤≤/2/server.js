const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const app = express();
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
//初始化静态资源
app.use(express.static('public'));
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.set('Content-Type', 'application/json');
    next();
});
app.get('/getstudent', (req, res) => {
    fs.readFile('data/data.json', 'utf-8', (err, data) => {
        if (err) {
            console.log('读取文件出错' + err);
            res.status(500).send('服务器错误')
        } else {
            res.status(500).send(data);
        }
    });
});

app.post('/addstudent', (req, res) => {
    fs.readFile('./data/data.json', (err, data) => {
        if (err) {
            console.log('读取文件出错' + err);
            res.status(500).send('服务器错误')
        } else {
            data = JSON.parse(data);
            let newObj = req.body;
            data.push(newObj);
            fs.writeFileSync('data/data.json', JSON.stringify(data, null, 4));
            res.status(200).send(newObj)
        }
    })
})
app.listen(3000, () => {
    console.log('3000开启');
})