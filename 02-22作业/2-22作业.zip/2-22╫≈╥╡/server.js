const express = require('express');
const app = express();
app.set('view engine', 'ejs');

const mongoose = require('mongoose');
let DB = mongoose.connect('mongodb://localhost/fdy', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('成功');
}, () => {
    console.log('失败');
});
const userSchema = new mongoose.Schema({
    name: String,
    age: Number,
    gender: String
});

const User = mongoose.model('xues', userSchema);

// const user = new User({
//     name: '张好看',
//     age: 11,
//     gender: '女'
// });
// user.save();

// ejs
app.get('/', (req, res) => {
    User.find().then((students) => {
        console.log(students);
        res.render('get', { students: students })
    });
});

//ajax
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Content-Type', 'application/json');
    next();
});
app.get('/api/student/getstudent', (req, res) => {
    User.find().then((data) => {
        console.log(data);
        res.send(data);
    });
});


app.listen(3000)