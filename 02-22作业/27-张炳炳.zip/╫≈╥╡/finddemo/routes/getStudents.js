const express = require('express');
const fs = require('fs');
const router = express.Router();

// 引入mongoose模块
const mongoose = require('mongoose');
// 连接数据库返回连接对象
const DB = mongoose.connect('mongodb://localhost/students', { useNewUrlParser: true, useFindAndModify: true });
// 设置连接状态提示
DB.then(() => {
    console.log('数据库连接成功');
}, () => {
    console.log('数据库连接失败');
});


// 定义集合规则
const studentsMessage = new mongoose.Schema({
    uname: String,
    age: Number,
    gender: String,
    tel: Number,
    hobby: Array,
    tag: String
});
// 创建集合
const User = mongoose.model('user', studentsMessage);
// const user = new User({
//     "uname": "李智",
//     "age": "23",
//     "gender": "男",
//     "tel": "13838438438",
//     "hobby": ["动漫", "游戏"],
//     "tag": "肥宅"
// });

// user.save();


// 查询
router.get('/getStudents', (req, res) => {
    var mydata;
    var results = [];
    let myid = req.query._id;
    let myuname = req.query.uname;
    if (myid) {
        User.find({ _id: myid }).then((result) => {
            transfer(result);
        });
    } else if (myuname) {
        User.find({ uname: myuname }).then((result) => {
            transfer(result);
        });
    } else {
        User.find().then((result) => {
            transfer(result);
        });
    };

    function transfer(result) {
        mydata = result;
        results = JSON.stringify(mydata);
        res.send(200, results);
    }

    // User.find().then((result) => {
    //     mydata = result;

    //     if (myid) {
    //         mydata.forEach((item) => {
    //             if (item._id == myid) {
    //                 results.push(item);
    //             };
    //         });
    //     } else if (myuname) {
    //         mydata.forEach((item) => {
    //             if (item.uname == myuname) {
    //                 results.push(item);
    //             };
    //         });
    //     } else {
    //         results = mydata;
    //     };
    //     results = JSON.stringify(results);
    //     res.send(200, results);
    // });
});




// 暴露接口
module.exports = router;