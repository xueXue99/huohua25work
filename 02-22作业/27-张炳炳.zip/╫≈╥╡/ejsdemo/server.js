// 引入模块
const express = require('express');
const ejs = require('ejs');

const fs = require('fs');

// 实例化
const app = express();

// 引入body-parser模块
const bodyParser = require('body-parser');
app.use(express.static(__dirname));
// 跨域请求
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Content-Type', 'application/json');
    next();
});

// 拦截请求
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// 设置express模板引擎
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');



app.get('/api/student/getStudents', (req, res) => {
    let results = [];
    fs.readFile('./data/students.json', 'utf-8', (err, data) => {
        if (err) {
            res.status(500).end();
            console.log(err);
        } else {
            let myid = req.query._id;
            let myuname = req.query.uname;
            console.log(myuname);
            data = JSON.parse(data);

            if (myid) {
                data.forEach((item) => {
                    if (item._id == myid) {
                        results.push(item);
                    };
                });
            } else if (myuname) {
                data.forEach((item) => {
                    if (item.uname == myuname) {
                        results.push(item);
                    };
                });
            } else {
                results = data;
            };
            console.log(results);
            res.type('html');
            res.render("index", { students: results });
        }
    });
});

app.post('/api/student/addStudents', (req, res) => {
    let results = [];
    fs.readFile('./data/students.json', 'utf-8', (err, data) => {
        if (err) {
            res.status(500).end();
            console.log(err);
        } else {
            data = JSON.parse(data);
            req.body._id = Date.now().toString();
            data.push(req.body);
            fs.writeFile('./data/students.json', JSON.stringify(data), (err) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log('写入成功');
                };
            });
            results = data;
            res.redirect('/');

        };
    });

});
app.get('/', (req, res) => {
    fs.readFile('./data/students.json', 'utf-8', (err, data) => {
        if (err) {
            res.status(500).end();
            console.log(err);
        } else {
            data = JSON.parse(data);
            res.type('html');
            res.render('index', { students: data })
        };
    });
});
app.listen(3000, () => {
    console.log('服务器已开启,端口号:3000');
});