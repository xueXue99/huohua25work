const http = require('http');
const fs = require('fs');
const queryString = require('querystring');
// 引入自定义模块
const writejson = require('./writejson/funjson.js');
// 服务器
let server = http.createServer((req, res) => {
    // 设置响应头
    res.writeHead(200, {
        "Content-Type": "text/html;charset=utf-8"
    })
    if (req.url != '/favicon.ico') {
        var reqstr = req.url.split('?')[1];
        // 转换为对象
        var obj = queryString.parse(reqstr);
        // 自定义模块来写入json
        writejson.setData(fs, obj, (data) => {
            res.write(data + '写入成功');
            // 结束监听
            res.end();
        });
    } else {
        res.write('404');
        // 结束监听
        res.end();
    };
});
// 设置监听端口
server.listen(3000, () => {
    console.log('server is running:3000');
});