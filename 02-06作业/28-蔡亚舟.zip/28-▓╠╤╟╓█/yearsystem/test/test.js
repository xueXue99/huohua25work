let aa = '123123';
module.exports.aa = aa;