// 根据用户的url的参数存储到json文件中
const http = require('http');
const fs = require('fs');
const queryString = require('querystring');
const writeJson = require('./write/funjson1.js');

let server = http.createServer((req, res) => {
    // 设置请求头
    res.writeHead(200, { "Content-Type": "text/html;charset=utf-8" });
    // http://localhost:3000/login?uname=张美丽&password=666

    if (req.url != '/favicon.ico') {
        let reqstr = req.url.split('?')[1];
        // 转换为对象
        let tempObj = queryString.parse(reqstr);
        // 自定义模块进行写入json操作
        writeJson.setData(fs, tempObj, (data) => {
            res.write(data + '写入成功');
            // 结束监听
            res.end();
        });
    } else {
        res.write('404');
        // 结束监听
        res.end();
    };
});
// 设置监听端口
server.listen(3000, () => {
    console.log('server is running:3000');
});